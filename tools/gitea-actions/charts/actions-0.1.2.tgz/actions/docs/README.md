# Gitea Actions Helm Chart Docs

- [Resource limits and capacity](./resources.md)
- [connectionCommandOverride explanation](./connectionCommandOverride.md)
